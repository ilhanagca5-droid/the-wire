# THE WIRE — Vercel Deploy Talimatları

## Klasör Yapısı
```
thewire/
├── api/
│   └── markets.js       ← Yahoo Finance proxy (serverless)
├── public/
│   └── index.html       ← Frontend
├── vercel.json          ← Routing config
└── package.json
```

---

## Adım 1 — Node.js Kur (yoksa)
https://nodejs.org → LTS sürümü indir ve kur.

---

## Adım 2 — Vercel CLI Kur
Terminal / PowerShell aç:
```
npm install -g vercel
```

---

## Adım 3 — Vercel Hesabı
https://vercel.com → GitHub ile ücretsiz kayıt ol.

---

## Adım 4 — Deploy Et
`thewire` klasörünün içinde terminal aç ve sırayla çalıştır:

```
cd thewire
vercel login
vercel --prod
```

`vercel login` seni tarayıcıya yönlendirir, GitHub ile giriş yap.
`vercel --prod` sorular sorar:
- "Set up and deploy?" → Y
- "Which scope?" → kendi hesabını seç
- "Link to existing project?" → N
- "Project name?" → the-wire (ya da istediğin isim)
- "In which directory?" → . (nokta, mevcut klasör)

Deploy biter, sana bir URL verir:
```
https://the-wire-xxxx.vercel.app
```

---

## Adım 5 — Test
Verilen URL'yi tarayıcıda aç.
Sol kenar çubuğunda borsa, döviz, emtia verileri canlı görünecek.

---

## Güncelleme
Dosyada değişiklik yaptıktan sonra tekrar:
```
vercel --prod
```

---

## Notlar
- Ücretsiz Vercel planı bu proje için yeterli.
- Yahoo Finance ara sıra rate-limit uygulayabilir → panelde "—" görünürse 1-2 dk bekle.
- `api/markets.js` içinde SYMBOLS listesini değiştirerek farklı hisseler ekleyebilirsin.
